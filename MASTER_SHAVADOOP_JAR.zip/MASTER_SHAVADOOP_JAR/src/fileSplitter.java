import java.util.ArrayList;
import java.io.*;


/**
 * 
 */

/**
 * @author lorraine
 *
 */
public class fileSplitter {

	public  ArrayList<String> myGoodMachines;
	private int myNumberOfMachines;
	public BufferedReader myBuff;
	public ArrayList<String> mySxNames ;
	public  FileReader myFile;		
	public String line;

	int cpt = 0;

	private String PATH;

	fileSplitter(int param_number_machines) throws FileNotFoundException
	{
		myNumberOfMachines =  param_number_machines;
		//PATH = "/home/lorraine/workspace/"; 
		PATH = "/cal/homes/lnyembi/workspace/";
		myFile = new FileReader(PATH + "Input.text");
		myBuff = new BufferedReader(myFile);
		myGoodMachines = new ArrayList<String>();
	}

	public int fileLinesCounter() throws IOException
	{
		int nbLines = 0;
		myFile = new FileReader(PATH + "Input.text");
		myBuff = new BufferedReader(myFile);
		while ((line = myBuff.readLine()) != null)
		{
			nbLines +=1;
		}
		
		System.out.printf("\nNombre de lignes dans le fichier d'entrée : %d\n", nbLines);
		myFile.close();
		myBuff.close();
		return nbLines;
	}
	public  void splitLines() throws IOException 
	{

		int totalNumberOfLines;

		totalNumberOfLines = fileLinesCounter();

		//System.out.print(myNumberOfMachines);
		myFile = new FileReader(PATH + "Input.text");
		myBuff = new BufferedReader(myFile);
		sxCreator sx = new sxCreator(totalNumberOfLines, myBuff, myFile);

		int nbLinesPerMachine;
		if( totalNumberOfLines >= myNumberOfMachines )
		{
			nbLinesPerMachine = (int)(totalNumberOfLines / myNumberOfMachines);
			
			
			if(totalNumberOfLines % myNumberOfMachines == 0) //rÃ©partition Ã©quitable des lignes
			{
				sx.fillSx_2(nbLinesPerMachine, myNumberOfMachines);
				
			}
			else //rÃ©partition non Ã©quitable des lignes
			{
				sx.fillSx_3(nbLinesPerMachine, myNumberOfMachines);
				

			}
		}
		else // je distribue dans autant de fichiers qu'il y a de lignes 
		{
			sx.fillSx(myBuff);	
			
		}

		mySxNames = sx.mySxNames;
		System.out.printf("\nNombre de fichiers Sx crees: %d\n", mySxNames.size());
		myFile.close();
		myBuff.close();
	}
}








