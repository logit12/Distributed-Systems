import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.util.ArrayList;

/**
 * 
 */

/**
 * @author lorraine
 *
 */
public class machinesCollector  {

	public  ArrayList<String> myGoodMachines;
	private BufferedReader myBuff;
	private  FileReader myFile;
	public String PATH;
	public String login;
	public boolean searchGoodMachine, isgoodMachine;
	
	private BufferedReader buff5;

	machinesCollector()
	{
		//PATH = "/home/lorraine/workspace/"; 
		PATH = "/cal/homes/lnyembi/workspace/";
		login = "lnyembi";
		searchGoodMachine = true;
	}
	
	public int getSizeFile(String filename) throws IOException 
	{
		int sizeF = 0;
		FileReader lfile = new FileReader(PATH + filename);
		buff5 = new BufferedReader(lfile);
		while (( buff5.readLine()) != null)
		{
			sizeF +=1;
		}
		
		
		return sizeF;
	}
	public  ArrayList<String> getGoodMachines2() throws FileNotFoundException
	{
		ArrayList<String> goodMachine = new ArrayList<String>();
		String machineName;

		try {
			myFile = new FileReader(PATH + "filetoread.text");
			myBuff = new BufferedReader(myFile);
			File newFile = new File(PATH + "goodMachines.text");
			FileWriter fw2 = new FileWriter(newFile, false);
			BufferedWriter writer2 = new BufferedWriter(fw2);

			while ((machineName = myBuff.readLine()) != null )
			{
				//System.out.println(line);
				
				//String[] commande = {"ssh", login + "@"+ line, "echo"," essai connection avec " + line};   /*"pwd"*///, 

				String[] commande = {"ssh", login + "@"+ machineName, "pwd"};   /*"pwd"*///, "echo essai connection avec " + line
				
				//String[] commande = {"ssh" ,line};
				ProcessBuilder pb = new ProcessBuilder(commande);
				Process p = pb.start();

				/*AfficheurFlux fluxSortie = new AfficheurFlux(p.getInputStream());
				AfficheurFlux fluxErreur = new AfficheurFlux(p.getErrorStream());

				new Thread(fluxSortie).start();
				new Thread(fluxErreur).start();*/

				p.waitFor();
		
				 
				if (p.exitValue() == 0)
				{				
					goodMachine.add(machineName);
					System.out.println("ok:" + machineName);
					/*File newFile = new File("/cal/homes/lnyembi/workspace/goodMachines.text");
					FileWriter fw2 = new FileWriter(newFile, true);
					BufferedWriter writer2 = new BufferedWriter(fw2);*/

					writer2.write(machineName + "\r\n");


				}
			}writer2.close();		
		} catch (IOException e) {
			e.printStackTrace();
		} catch (InterruptedException e) {
			e.printStackTrace();
		}


		return goodMachine;				
	}
	
	public  ArrayList<String> setGoodMachines() throws IOException
	{
		ArrayList<String> goodMachine = new ArrayList<String>();
		String machineName;
		
		try {
			myFile = new FileReader(PATH + "filetoread.text");
			myBuff = new BufferedReader(myFile);
			File newFile = new File(PATH + "goodMachines.text");
			
			FileWriter fw2 = new FileWriter(newFile, false);
			BufferedWriter writer2 = new BufferedWriter(fw2);
			int sizeFile = getSizeFile("filetoread.text");
			
			BufferedReader myBuff2 = new BufferedReader(myFile);
			
			System.out.printf("essai connection avec %d machines \n", sizeFile);
			Runner_slave[] runner_slave = new Runner_slave[sizeFile];
			
			
			int i =0;
			while ((machineName = myBuff2.readLine()) != null )
			{
								
				runner_slave[i] = new Runner_slave(machineName, true , writer2, false);

				runner_slave[i].start();
				//runner_slave[i].join();

				/*if(runner_slave[i].isgoodMachine)
					goodMachine.add(runner_slave[i].goodIP);*/
				
				i++;
				 
				
			}
			for (int k = 0; k<sizeFile ; k++ )
			{

				runner_slave[k].join();
				if(runner_slave[k].isgoodMachine)
				  {goodMachine.add(runner_slave[k].goodIP);}
			

			}
			
			writer2.close();		
		} catch (IOException e) {
			e.printStackTrace();
		} catch (InterruptedException e) {
			e.printStackTrace();
		}


		myGoodMachines = goodMachine;
		System.out.printf("Connection réussie avec %d machines \n", myGoodMachines.size());
		return goodMachine;				
	}

	public void getGoodMachine() throws IOException
	{
		myGoodMachines = setGoodMachines();
		
	}

	public void connectToMachines(String paramMachine, String paramCmd) throws InterruptedException
	{

		String[] cmd_2 = {"ssh", "lnyembi@" + paramMachine , paramCmd}; 	
		//String[] cmd_2 = {"ssh", "lnyembi@"+ myGoodMachines.get(0) , "java -jar /cal/homes/lnyembi/workspace/slave.jar"};

		ProcessBuilder pb2 = new ProcessBuilder(cmd_2);
		Process p2;
		try {
			p2 = pb2.start();
			InputStream value = p2.getInputStream();                         //rÃ©cupÃ¨re le resultat du calcul au niveau systÃ¨me
			InputStreamReader value_read = new InputStreamReader(value);     //crÃ©e un un reader 
			BufferedReader bufferedReader = new BufferedReader(value_read); // envoie le reader dans le duffer

			//BufferedReader bufferedReader = new BufferedReader(new InputStreamReader(process.getInputStream()));
			String line2;
			while((line2 = bufferedReader.readLine()) != null){
				System.out.println(paramMachine + " " + line2);
			}
			p2.waitFor();
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}


	}
}