import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.io.Reader;
import java.util.ArrayList;
import java.util.HashMap;

class Runner_slave extends Thread {

	private String ip;
	public String goodIP;
	private String mSxName;
	private String mUMxName;
	private AfficheurFlux fluxSortie, fluxErreur;
	public InputStream inputStreamSlavex;
	public BufferedReader br;

	public String startDico;

	private boolean msearchGoodMachine;
	public boolean isgoodMachine;
	public ArrayList<String> myUMxLines, myRMxLines;
	public String workingMode;  //ModeSxUMx or ModeUMxSx
	public String mKey; 
	public String  mUMxWordPath;
	private String PATH ; 
	private int idxMx;
	private BufferedWriter mwriter;
	
	
	public String getIp() {
		return ip;
	}

	public void setIp(String ip) {
		this.ip = ip;
	}

	public Runner_slave(String ip, String sxName, boolean searchGoodMachine) {
		super();
		this.ip = ip;
		this.mSxName = sxName; 
		
		startDico = "";
		myUMxLines= new ArrayList<String>();
		workingMode = "ModeSxUMx";
		this.msearchGoodMachine = searchGoodMachine; 
	}

	public Runner_slave(String ip, boolean searchGoodMachine, BufferedWriter writer ,  boolean isgoodMachine) {
		super();
		this.ip = ip;
		this.isgoodMachine = isgoodMachine;
		this.msearchGoodMachine = searchGoodMachine; 
		this.mwriter = writer;
		
	}

	public Runner_slave(String ip, int idxMx, String mode,  String key, String sxName, String umxName, boolean searchGoodMachine) {
		super();
		this.ip = ip;
		this.idxMx = idxMx;
		this.mSxName = sxName; 
		this.mUMxName = umxName;
		this.mKey = key;
		startDico = "";
		myRMxLines= new ArrayList<String>();
		workingMode = mode;
		mUMxWordPath = "";
		PATH = "/home/lorraine/workspace/"; 
		this.msearchGoodMachine = searchGoodMachine; 
	}

	/*public Runner_slave(String sxName) {
		super();

		this.mSxName = sxName; 
	}*/

	@Override
	public void run() {
		ProcessBuilder pb2 = null;

		if(msearchGoodMachine == true)
		{
			String[] cmdSearchMachine = {"ssh", "lnyembi@"+ ip, " "};   /*"pwd"*///, "echo essai connection avec " + line
			
			pb2 = new ProcessBuilder(cmdSearchMachine);
			Process p1;
			try {
				p1 = pb2.start();
				
				fluxSortie = new AfficheurFlux(p1.getInputStream());
				fluxErreur = new AfficheurFlux(p1.getErrorStream());
				Thread Sortie = new Thread(fluxSortie);
				Thread Erreur = new Thread(fluxErreur);

				Erreur.start();
				Sortie.start();

				
				p1.waitFor();
				
				if (p1.exitValue() == 0)
				{				
					goodIP = ip;
					System.out.println("ok:" + ip);
					mwriter.write(ip + "\r\n");

					isgoodMachine = true;
				}

			}catch (IOException | InterruptedException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
			
		}

		else
		{

			if (workingMode.compareTo("ModeSxUMx") == 0){
				String[] cmd_2 = {"ssh", "lnyembi@"+ ip , "java -jar /cal/homes/lnyembi/workspace/slave.jar " + mSxName}; //ok q30
				pb2 = new ProcessBuilder(cmd_2);
			}
			if (workingMode.compareTo("ModeUMxSx") == 0){
				String[] cmd_2 = {"ssh", "lnyembi@"+ ip , "java -jar /cal/homes/lnyembi/workspace/slave.jar " + workingMode + " " + Integer.toString(idxMx) + " " + mKey + " " + mSxName + " " + mUMxName };


				//String[] cmd_2 = {"ssh", "lnyembi@"+ ip , "java -jar /cal/homes/lnyembi/workspace/slave.jar "};
				pb2 = new ProcessBuilder(cmd_2);
			}
			Process p2;
			try {
				p2 = pb2.start();


				fluxSortie = new AfficheurFlux(p2.getInputStream());

				// get the input stream of the process and print it

				fluxErreur = new AfficheurFlux(p2.getErrorStream());


				Thread Sortie = new Thread(fluxSortie);
				Thread Erreur = new Thread(fluxErreur);

				Erreur.start();
				Sortie.start();

				//Erreur.join();
				//   Sortie.join();

				p2.waitFor();


				if (p2.exitValue() == 0)
				{				
					//start creation of dico UMx

					if (workingMode.compareTo("ModeSxUMx") == 0){
						fluxSortie.run();
						inputStreamSlavex = p2.getInputStream();
						startDico = "****************Construction du dictionnaire “clés-UMx”****************************************";

						for( int k = 0; k< fluxSortie.str.size(); k++)
						{

							myUMxLines.add(fluxSortie.str.get(k));

						}
						mUMxWordPath= PATH + "UMx" + idxMx + ".text";


						//	myUMxLines = fluxSortie.str;
					}
					if (workingMode.compareTo("ModeUMxSx") == 0){
						fluxSortie.run();
						inputStreamSlavex = p2.getInputStream();


						for( int k = 0; k< fluxSortie.str.size(); k++)
						{
							myRMxLines.add(fluxSortie.str.get(k));
						}

					}

				}


			} catch (IOException | InterruptedException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		}//end else


	}//end run
}

