/*import java.io.*;
import java.util.ArrayList;
import java.util.Enumeration;
import java.util.Hashtable;


public class master {

	private static BufferedReader buff;
	private static FileReader file;
	private static ArrayList<String> myGoodMachines;
	private static ArrayList<String> mySxName;
	private static Boolean  machinesFoundBool = false;
	private static int nbSxFiles ;

	private static Hashtable<String, ArrayList<String>>  myDICO ;

	public master() //ne sera pas appelé
	{
		myDICO = new Hashtable<String, ArrayList<String>>();
		nbSxFiles = 0;
	}

	public static ArrayList<String> getGoodMachines() throws FileNotFoundException
	{
		ArrayList<String> goodMachine = new ArrayList<String>();
		String line;

		try {
			file = new FileReader("/cal/homes/lnyembi/workspace/filetoread.text");
			buff = new BufferedReader(file);
			File newFile = new File("/cal/homes/lnyembi/workspace/goodMachines.text");
			FileWriter fw2 = new FileWriter(newFile, false);
			BufferedWriter writer2 = new BufferedWriter(fw2);

			while ((line = buff.readLine()) != null)
			{

				String[] commande = {"ssh", "lnyembi@"+ line , "echo essai connection avec " + line};   "pwd"
				ProcessBuilder pb = new ProcessBuilder(commande);
				Process p = pb.start();

				AfficheurFlux fluxSortie = new AfficheurFlux(p.getInputStream());
				AfficheurFlux fluxErreur = new AfficheurFlux(p.getErrorStream());

				new Thread(fluxSortie).start();
				new Thread(fluxErreur).start();

				p.waitFor();

				if (p.exitValue() == 0)
				{				
					goodMachine.add(line);
					File newFile = new File("/cal/homes/lnyembi/workspace/goodMachines.text");
					FileWriter fw2 = new FileWriter(newFile, true);
					BufferedWriter writer2 = new BufferedWriter(fw2);

					writer2.write(line + "\r\n");


				}
			}writer2.close();		
		} catch (IOException e) {
			e.printStackTrace();
		} catch (InterruptedException e) {
			e.printStackTrace();
		}


		return goodMachine;				
	}

	public static void connectToMachines(String paramMachine, String paramCmd) throws InterruptedException
	{

		String[] cmd_2 = {"ssh", "lnyembi@" + paramMachine , paramCmd}; 	//String[] cmd_2 = {"ssh", "lnyembi@"+ myGoodMachines.get(0) , "java -jar /cal/homes/lnyembi/workspace/slave.jar"};

		ProcessBuilder pb2 = new ProcessBuilder(cmd_2);
		Process p2;
		try {
			p2 = pb2.start();
			InputStream value = p2.getInputStream();                         récupère le resultat du calcul au niveau système
			InputStreamReader value_read = new InputStreamReader(value);     crée un un reader 
			BufferedReader bufferedReader = new BufferedReader(value_read); // envoie le reader dans le duffer

			//BufferedReader bufferedReader = new BufferedReader(new InputStreamReader(process.getInputStream()));
			String line2;
			while((line2 = bufferedReader.readLine()) != null){
				System.out.println(paramMachine + " " + line2);
			}
			int ret = p2.waitFor();
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}


	}

	Q25
	public static ArrayList<String> splitLines()
	{

		String line;
		ArrayList<String> locsxName = new ArrayList<String>() ;
		int cpt = 0;

		try {
			file = new FileReader("/cal/homes/lnyembi/workspace/Input.text");
			buff = new BufferedReader(file);


			int cptMachine = 1;

			while ((line = buff.readLine()) != null)
			{
				System.out.println(line);
				File newFile = new File("/cal/homes/lnyembi/workspace/Sx" + cptMachine + ".text");

				locsxName.add("/cal/homes/lnyembi/workspace/Sx" + cptMachine + ".text");
				//System.out.println("/cal/homes/lnyembi/workspace/Sx" + cptMachine + ".text");

				FileWriter fw2 = new FileWriter(newFile);
				BufferedWriter writer2 = new BufferedWriter(fw2);
				cptMachine = cptMachine + 1;
				writer2.write(line + "\r\n");
				writer2.close();
				//newFile.delete();
				cpt++;


			}
			file.close();
			buff.close();

		} catch (IOException e) {
			e.printStackTrace();
		}

		mySxName = locsxName;
		return mySxName;
	}


	Q28

	public static void getMyDICO() throws IOException
	{
		ArrayList<String> myUMxName =  new ArrayList<String>() ;
		String UmxFile = "";
		int j = 0;
		int k = j;
		Enumeration<String> keys ;

		// Remplissage d'un nouveau Hashtable
		for (j = 1; j<nbSxFiles ;j++)
		{

			String line;
			try {
				// Pour chaque UMx
				//UmxFile = "/cal/homes/lnyembi/workspace/UMx" + (j+1) + ".text";	
				FileReader file = new FileReader("/cal/homes/lnyembi/workspace/UMx" + j + ".text");
				System.out.println("/cal/homes/lnyembi/workspace/UMx" + j + ".text");

				BufferedReader buff2 = new BufferedReader(file);
				while ((line = buff2.readLine()) != null)
				{
					if(k==1)  //pour le parcours du 1er UMx
					{
						myUMxName.add("UMx" + 1);
						k = 2;
					}
					else  //à partir du deuxième UMx
					{
						myUMxName.add("UMx" + j);
					//}
					myDICO.put(line, myUMxName);
				}
				file.close();
				buff2.close();
			} catch (FileNotFoundException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}


		}


		keys = myDICO.keys();
		while (keys.hasMoreElements())
		{
			String key = (String)keys.nextElement();
			ArrayList<String> stateName = myDICO.get(key);

			System.out.println( key + " : <");
			for(int i=0;i< stateName.size();i++){
				System.out.println(stateName.get(i));
			}

			System.out.println( ">");
		}


	}
	public static void main(String[] args) throws IOException, InterruptedException {

		Question 25
		ArrayList<String> locSxNames = splitLines();
		myDICO = new Hashtable<String, ArrayList<String>>();
		Question 20
		if (machinesFoundBool == false)
		{
			myGoodMachines = getGoodMachines();
			machinesFoundBool = true;
		}
		System.out.printf("%d",myGoodMachines.size());

		if (!myGoodMachines.isEmpty())
		{

			System.out.printf("\nLecture fichier: %d machine(s) trouvée(s)\n", myGoodMachines.size());

			String locCmd = "java -jar /cal/homes/lnyembi/workspace/slave.jar";	
			connectToMachines(myGoodMachines.get(0), locCmd);

			int nbOfGoodMachines = myGoodMachines.size();
			nbSxFiles = locSxNames.size();
			Runner_slave[] runner_slave = new Runner_slave[nbOfGoodMachines];

			// Question  27

			// On s'assure qu'il y a au moins autant de slaves que de fichiers Sx
			if (nbOfGoodMachines >= nbSxFiles)
			{	

				for (int i = 0; i< nbSxFiles; i++)
				{
					//for (i ; i< runner_slave.length; i++){
					System.out.printf("On lance SLAVE sur %s\n", myGoodMachines.get(i));
					System.out.printf("UM%d -%s\n", i, myGoodMachines.get(i));
					runner_slave[i] = new Runner_slave(myGoodMachines.get(i) , locSxNames.get(i));
					runner_slave[i].start();
					//}


					for (int i = 0; i< runner_slave.length; i++){
																										runner_slave[i].join();
																								 }
				}
				System.out.println("tout est fini");
			}
			else //A optimiser plus tard
			{
				for (int k = 0; k<nbSxFiles; k++)
				{

					System.out.printf("On lance SLAVE sur %s\n", myGoodMachines.get(0));
					runner_slave[0] = new Runner_slave(myGoodMachines.get(0), locSxNames.get(k));													
					runner_slave[0].start();
				}
				System.out.println("tout est fini");
			}

		}
		getMyDICO();


	}	





}




 */





/**
 * 
 */

/**
 * @author lorraine
 *
 */

import java.io.*;
import java.util.ArrayList;
import java.util.Enumeration;
import java.util.HashMap;
import java.util.HashSet;
import java.util.Hashtable;
import java.util.Iterator;


public class  master {

	private static BufferedReader buff;
	private static FileReader file;
	private static ArrayList<String> myGoodMachines;
	private static ArrayList<String> mySxName;
	private static Boolean  machinesFoundBool = false;
	private static int nbSxFiles ;
	private static String PATH ;

	private static Hashtable<String, ArrayList<String>>  myDICO ;

	public static ArrayList<String> myUMxLines;

	public static HashMap<String, ArrayList<String>>  myDICO_UMxWordPath ;

	public static String workingMode;  //ModeSxUMx or ModeUMxSx

	public  master() //ne sera pas appelÃ©
	{
		myDICO = new Hashtable<String, ArrayList<String>>();
		nbSxFiles = 0;
		//PATH = "/home/lorraine/workspace/"; 
		PATH = "/cal/homes/lnyembi/workspace/";
		myUMxLines = new ArrayList<String> ();
		myDICO_UMxWordPath = new HashMap<String, ArrayList<String>>();
		
	}


	public static void main(String[] args) throws IOException, InterruptedException {

		long startTime , endTime , totalTime ;

		HashMap<String, ArrayList<String>>  myDICO_UMxWord = new HashMap<String, ArrayList<String>>();
		HashMap<String, HashSet<String>>  myDICO_WordUMx = new HashMap<String, HashSet<String>>();
	
		HashMap<String, String>  myDICO_UMxMachines = new HashMap<String, String>();
		HashMap<String, String>  myDICO_FinalResult = new HashMap<String, String>();
		ArrayList<String> myRMxLines = new ArrayList<String>();
		String umxName = "";

		
		/*Question 25*/
		PATH = "/cal/homes/lnyembi/workspace/";

		//ArrayList<String> locSxNames = splitLines();
		myDICO = new Hashtable<String, ArrayList<String>>();
		/*Question 20*/

		System.out.println("****************Collecte de machines viables pour le traitement*************************\n");

		startTime = System.currentTimeMillis();

		machinesCollector machine = new machinesCollector();
		machine.setGoodMachines();
		myGoodMachines = machine.myGoodMachines;
		
		endTime  = System.currentTimeMillis();
		totalTime = endTime - startTime;
		System.out.printf("\nTemps de Démarrage : %d ms\n\n",totalTime);
		
		//System.out.printf("\nNombre de machines viables : %d\n\n",.size());

	
		System.out.println("\n*********Split Mapping en parallèle : découpage du fichier en sous-fichiers**************\n");
		
		
		/**************************************************************************************/
		/*
		/*								SPLITTING PROCESSING BY MASTER
		/*
		/**************************************************************************************/
		startTime = System.currentTimeMillis();

		fileSplitter splitter = new fileSplitter(myGoodMachines.size());
		splitter.splitLines();
		
		endTime  = System.currentTimeMillis();
		totalTime = endTime - startTime;
		System.out.printf("\nTemps de Splitting : %d\n\n",totalTime);
		startTime = System.currentTimeMillis();

		
		
		//if (!myGoodMachines.isEmpty())  //OK

		
		
		//{

		System.out.printf("\n********Construction du dictionnaire “UMx - machines“*******************************\n\n");

		//String locCmd = "java -jar " + PATH + "slave.jar";	
		//machine.connectToMachines(myGoodMachines.get(0), locCmd);

		int nbOfGoodMachines =  myGoodMachines.size();
		nbSxFiles = splitter.mySxNames.size();
		Runner_slave[] runner_slave = new Runner_slave[nbOfGoodMachines];
		mapperDictionnary dico = new mapperDictionnary();
		
	
		workingMode= "ModeSxUMx";
		
		/**************************************************************************************/
		/*
		/*								MAPPING PROCESSING BY SLAVES
		/*
		/**************************************************************************************/
		
		
		if ((workingMode.compareTo("ModeSxUMx") )== 0)   
		{
			//System.out.printf("On lance SLAVE sur %s\n", myGoodMachines.get(i));
			
			for (int i = 0; i< nbSxFiles; i++)
			{

				String s= "UMx"+ (i+1);
				//System.out.printf("On lance SLAVE sur %s\n", myGoodMachines.get(i));
				System.out.printf("UMx%d - %s\n", i+1, myGoodMachines.get(i));

				myDICO_UMxMachines.put(s,  myGoodMachines.get(i));

			}
			System.out.println(myDICO_UMxMachines.toString());
			System.out.printf("\n********Fin Construction du dictionnaire “UMx - machines“*******************************\n");

			for (int i = 0; i< nbSxFiles; i++)
			{

				runner_slave[i] = new Runner_slave(myGoodMachines.get(i) , splitter.mySxNames.get(i), false); 
				System.out.println(runner_slave[i].startDico);
				runner_slave[i].start();
				
				/*runner_slave[i].join();
				String s= "UMx"+ (i+1);
				HashSet<String> myUMxName = new HashSet<String>();
				myUMxName.add(s);
				
				umxName = umxName + PATH + s + ".text ";
				
				for (int ii = 0; ii< runner_slave[i].myUMxLines.size(); ii++){
					myDICO_UMxWord.put(s,  runner_slave[i].myUMxLines);
				}*/

			}
			for (int i = 0; i< nbSxFiles; i++)
			{

				/*
				HashSet<String> myUMxName = new HashSet<String>();
				
				runner_slave[i] = new Runner_slave(myGoodMachines.get(i) , splitter.mySxNames.get(i), false); 

				System.out.println(runner_slave[i].startDico);
				runner_slave[i].start();*/
				runner_slave[i].join();

				String s= "UMx"+ (i+1);
				HashSet<String> myUMxName = new HashSet<String>();
				myUMxName.add(s);
				
				umxName = umxName + PATH + s + ".text ";
				
				for (int ii = 0; ii< runner_slave[i].myUMxLines.size(); ii++){
					myDICO_UMxWord.put(s,  runner_slave[i].myUMxLines);
				}

			}
			myDICO_WordUMx = dico.getMyDICO_WordToUM(myDICO_UMxWord);
			workingMode= "ModeUMxSx";

		}
		
		endTime  = System.currentTimeMillis();
		totalTime = endTime - startTime;
		System.out.printf("\nTemps de Mapping : %d ms\n\n",totalTime);
		
		startTime = System.currentTimeMillis();
	    
		if(workingMode.equals("ModeUMxSx") ==true)
		{
			
			Iterator<String> keyIt = myDICO_WordUMx.keySet().iterator();

			int i = 0;
			assembling finalMaster = new assembling();
		    while (keyIt.hasNext()) 
		    {
		    	
		        String valKey = keyIt.next();
		        
		       
				runner_slave[i] = new Runner_slave(myGoodMachines.get(i) , (i+1) , workingMode , valKey, splitter.mySxNames.get(0), umxName, false);

				runner_slave[i].start();
				/*runner_slave[i].join();

				for (String lineRm : runner_slave[i].myRMxLines){
					myRMxLines.add(lineRm);
				}*/

				i++;
			}
		    i=0;
		    while (keyIt.hasNext()) 
		    {
		    	
		       /* String valKey = keyIt.next();
		        
		       
				runner_slave[i] = new Runner_slave(myGoodMachines.get(i) , (i+1) , workingMode , valKey, splitter.mySxNames.get(0), umxName, false);

				runner_slave[i].start();*/
				runner_slave[i].join();

				for (String lineRm : runner_slave[i].myRMxLines){
					myRMxLines.add(lineRm);
				}

				i++;
			}
		    endTime  = System.currentTimeMillis();
			totalTime = endTime - startTime;
			System.out.printf("\nTemps de SHUFFLING/REDUCING : %d ms\n\n",totalTime);

			/**************************************************************************************/
			/*
			/*								ASSEMBLING PROCESSING BY MASTER
			/*
			/**************************************************************************************/
		    startTime = System.currentTimeMillis();
		    
		    finalMaster.doAssembling(PATH, myRMxLines);
		    
			endTime  = System.currentTimeMillis();
			totalTime = endTime - startTime;
			System.out.printf("\nTemps de ASSEMBLING : %d ms\n\n",totalTime);

		}
			
		/*ArrayList<String> sample = new ArrayList<String>(3);
		sample.add("beer");
		sample.add("deer");
		sample.add("car");*/
		/*"****************Construction du dictionnaire “clés -UMx”****************************************\n")*/
		//dico.quicksort(sample, 0, 2);


		//}

		//dico.getMyDICO(myDICO_UM);

		System.out.println("****************Tout est fini***************************************************\n");



	}	





}