import java.io.*;
import java.util.ArrayList;
import java.util.Collection;
import java.util.Enumeration;
import java.util.Hashtable;
import java.util.HashMap;
import java.util.HashSet;
import java.util.Iterator;
import java.util.Set;
import java.util.Collections;
import java.util.Comparator;
import java.util.LinkedHashMap;
import java.util.LinkedList;
import java.util.List;



public class mapperDictionnary {



	public mapperDictionnary()
	{

	}

	public  HashMap<String, HashSet<String>> getMyDICO_WordToUM(HashMap<String, ArrayList<String>> param_UMxWordDico) throws IOException
	{
		System.out.println(param_UMxWordDico.toString());

		HashMap<String, HashSet<String>> myDICO_WordUMx = new HashMap<String, HashSet<String>>();


		for (int i = 0; i< param_UMxWordDico.size(); i++)
		{
			ArrayList<String> myUMxName = new ArrayList<String>();

			String UM_courant = (String) param_UMxWordDico.keySet().toArray()[i];
			myUMxName.add((String) param_UMxWordDico.keySet().toArray()[i]);



			ArrayList<String> keys_ = new ArrayList<String>();
			keys_ = (ArrayList<String>)param_UMxWordDico.get(UM_courant);

			//	System.out.println((String) myDICO_UM0.keySet().toArray()[i]);

			for(int j = 0; j< keys_.size(); j++)
			{
				String key = keys_.get(j);

				if(myDICO_WordUMx.containsKey(key) == false)
				{


					HashSet<String> list = new HashSet<String>();
					list.add(UM_courant);
					myDICO_WordUMx.put(key, list );


					//System.out.println(myDICO_UM.toString());

				}
				else
				{
					myDICO_WordUMx.get(key).add(UM_courant);

					//System.out.println(myDICO_UM.toString());
				}
			}

		}
		System.out.println(myDICO_WordUMx.toString());
		return myDICO_WordUMx;

	}

	public  void quicksort(ArrayList<String> tableau, int start, int end) {
	    if (start < end) {
	        int indicePivot = partition(tableau, start, end);
	        quicksort(tableau, start, indicePivot-1);
	        quicksort(tableau, indicePivot+1, end);
	    }
	    
	    System.out.println(tableau.toString());
	}

	public  int partition (ArrayList<String> t, int start, int end) {
	    String valeurPivot = t.get(start);
	    int d = start+1;
	    int f = end;
	    while (d < f) {
	        while(d < f && t.get(f).compareTo(valeurPivot)>0) f--;
	        while(d < f && t.get(d).compareTo(valeurPivot)<0) d++;
	        String temp = t.get(d);
	        t.get(d).replace(t.get(d), t.get(f));
	        t.get(f).replace(t.get(f),  temp);
	    }
	    if (t.get(d).compareTo(valeurPivot)>0) d--;
	    t.get(start).replace( t.get(start), t.get(d));
	    t.get(d).replace(t.get(d), valeurPivot);
	    return d;
	}
	
	//public LinkedHashMap<Integer, String> sortHashMapByValues( HashMap<Integer, String> passedMap)
	public LinkedHashMap<String, ArrayList<String>> sortHashMapByValues( HashMap<String, ArrayList<String>> passedMap)
	{
	    List<String> mapKeys = new ArrayList<>(passedMap.keySet());
	    Collection<ArrayList<String>> mapValues = passedMap.values();
	    
	  //  Collections.sort(mapValues);
	    Collections.sort(mapKeys);

	    LinkedHashMap<String, ArrayList<String>>  sortedMap = new LinkedHashMap<>();
/*
	    Iterator<String> valueIt = mapValues.iterator();
	    
	    while (valueIt.hasNext()) {
	        String val = valueIt.next();
	        Iterator<Integer> keyIt = mapKeys.iterator();

	        while (keyIt.hasNext()) {
	            Integer key = keyIt.next();
	            String comp1 = passedMap.get(key);
	            String comp2 = val;

	            if (comp1.equals(comp2)) {
	                keyIt.remove();
	                sortedMap.put(key, val);
	                break;
	            }
	        }
	    }*/
	    return sortedMap;
	}


	
	

}
