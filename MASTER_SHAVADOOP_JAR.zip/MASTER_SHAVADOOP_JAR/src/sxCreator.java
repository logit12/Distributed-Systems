import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.File;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;
import java.util.ArrayList;

/**
 * 
 */

/**
 * @author lorraine
 *
 */

public class sxCreator {


	public BufferedReader myBuff;
	int nbLinesPerMachine ;
	public  FileReader myFile;
	public ArrayList<String> mySxNames;
	public String line;
	public String PATH;

	public sxCreator(int param_totalNumberOfLines, BufferedReader paramBuff, FileReader paramFile)
	{
		myBuff= paramBuff;
		nbLinesPerMachine = param_totalNumberOfLines;
		myFile = paramFile;
		//PATH = "/home/lorraine/workspace/"; 
		PATH = "/cal/homes/lnyembi/workspace/";
		mySxNames = new ArrayList<String>();
	}

	public void fillSx(BufferedReader paramBuff) throws IOException
	{

		int cptMachine = 1;
		
		while ((line = paramBuff.readLine()) != null)
		{
			
			File newFile = new File( PATH + "Sx" + cptMachine + ".text");
			mySxNames.add(PATH + "Sx" + cptMachine + ".text");

			FileWriter fw2 = new FileWriter(newFile);
			BufferedWriter writer2 = new BufferedWriter(fw2);
			cptMachine = cptMachine + 1;
			writer2.write(line + "\r\n");
			writer2.close();

		}
		myFile.close();
		myBuff.close();
				
	}
	public void fillSx_2(int param_nbLinesPerMachine, int param_nbOfMachines) throws IOException
	{
		int cptLine = 0;
		for (int k = 0 ; k < param_nbOfMachines; k++)
		{
			File newFile = new File( PATH + "Sx" + k + ".text");
			FileWriter fw2 = new FileWriter(newFile);
			BufferedWriter writer2 = new BufferedWriter(fw2);
			
			while ((line = myBuff.readLine()) != null && cptLine < param_nbLinesPerMachine)
			{
				mySxNames.add(PATH + "Sx" + k + ".text");
				//System.out.println(PATH + "Sx" + k + ".text");
				writer2.write(line + "\r\n");
				cptLine += 1;
			}
			
			writer2.close();
			cptLine = 0;	
		}
		myFile.close();
		myBuff.close();
				
	}
	public void fillSx_3(int param_nbLinesPerMachine, int param_nbOfMachines) throws IOException
	{
		int cptLine = 0;
		int kk = 0 ;
		for (int k = 0 ; k < param_nbOfMachines-1; k++)
		{
			File newFile = new File( PATH + "Sx" + k + ".text");
			FileWriter fw2 = new FileWriter(newFile);
			BufferedWriter writer2 = new BufferedWriter(fw2);
			
			while ((line = myBuff.readLine()) != null && cptLine < param_nbLinesPerMachine)
			{
				mySxNames.add(PATH + "Sx" + k + ".text");
				//System.out.println(PATH + "Sx" + k + ".text");
				writer2.write(line + "\r\n");
				cptLine += 1;
			}
			
			writer2.close();
			cptLine = 0;	
			kk = k;
		}
		
		File newFile = new File( PATH + "Sx" + kk + ".text");
		FileWriter fw = new FileWriter(newFile);
		BufferedWriter writer2 = new BufferedWriter(fw);
		
		while ((line = myBuff.readLine()) != null)
		{
			mySxNames.add(PATH + "Sx" + kk + ".text");
			//System.out.println(PATH + "Sx" + kk + ".text");
			writer2.write(line + "\r\n");
			
		}
		
		writer2.close();
		
		myFile.close();
		myBuff.close();
				
	}

}


