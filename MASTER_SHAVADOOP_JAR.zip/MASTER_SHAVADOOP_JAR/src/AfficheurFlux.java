import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;

import java.util.ArrayList;

class AfficheurFlux implements Runnable {

    private final InputStream inputStream;
    public ArrayList<String> str;

    AfficheurFlux(InputStream inputStream) {
        this.inputStream = inputStream;
        str= new ArrayList<String>();
    }

    private BufferedReader getBufferedReader(InputStream is) {
        return new BufferedReader(new InputStreamReader(is));
    }

    @Override
    public void run() {
    	BufferedReader br = getBufferedReader(inputStream);
        String ligne = "";
        try {
            while ((ligne = br.readLine()) != null) {
                System.out.println(ligne);
                str.add(ligne);
            }
        } catch (IOException e) {
            e.printStackTrace();
        }
    }
}

