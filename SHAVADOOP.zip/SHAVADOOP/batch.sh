#!/bin/bash

myPath='/cal/homes/lnyembi/workspace/'
fileWithAllMachinesName='filetoread.text'
input_file_name='Input.text'
myJar='master_final.jar'

java -jar $myJar $myPath $fileWithAllMachinesName $input_file_name
