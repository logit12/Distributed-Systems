import java.util.ArrayList;
import java.io.*;


/**
 * 
 */

/**
 * @author lorraine
 *
 */
public class fileSplitter {

	public  ArrayList<String> myGoodMachines;
	private int myNumberOfMachines;
	public BufferedReader myBuff;
	public ArrayList<String> mySxNames ;
	public  FileReader myFile;		
	public String line;

	int cpt = 0;

	private String PATH;
	

	fileSplitter(int param_number_machines, String param_input_file_name) throws FileNotFoundException
	{
		myNumberOfMachines =  param_number_machines;
		
		myFile = new FileReader(param_input_file_name);
		myBuff = new BufferedReader(myFile);
		myGoodMachines = new ArrayList<String>();
	}

	public int fileLinesCounter(String fileToSplit) throws IOException
	{
		int nbLines = 0;
		myFile = new FileReader(fileToSplit);
		myBuff = new BufferedReader(myFile);
		while ((line = myBuff.readLine()) != null)
		{
			nbLines +=1;
		}
		
		System.out.printf("\nNombre de lignes dans le fichier d'entrée : %d\n", nbLines);
		myFile.close();
		myBuff.close();
		return nbLines;
	}
	public  int  splitLines(String fileToSplit) throws IOException 
	{
		int totalNumberOfLines;
		int lSxNames = 0;

		totalNumberOfLines = fileLinesCounter(fileToSplit);

		myFile = new FileReader(fileToSplit);
		myBuff = new BufferedReader(myFile);
		sxCreator sx = new sxCreator(totalNumberOfLines, myBuff, myFile);

		int nbLinesPerMachine;
		if( totalNumberOfLines >= myNumberOfMachines )
		{
			nbLinesPerMachine = (int)(totalNumberOfLines / myNumberOfMachines);
			System.out.printf("\nnbLinesPerMachine: %d\n",nbLinesPerMachine);
			
			if(totalNumberOfLines % myNumberOfMachines == 0) //rÃ©partition Ã©quitable des lignes
			{
				System.out.printf("\n case 1: ");
				lSxNames = sx.fillSx_2(nbLinesPerMachine, myNumberOfMachines);
				mySxNames = sx.mSxNames;
				
			}
			else //rÃ©partition non equitable des lignes
			{
				System.out.printf("\n case 2: ");
				lSxNames = sx.fillSx_3(nbLinesPerMachine, myNumberOfMachines);
				mySxNames = sx.mSxNames;
				

			}
		}
		else // je distribue dans autant de fichiers qu'il y a de lignes 
		{
			lSxNames = sx.fillSx(myBuff);	
			mySxNames = sx.mSxNames;
			
		}

		
		System.out.printf("\nNombre de fichiers Sx crees: %d\n", mySxNames.size());
		myFile.close();
		myBuff.close();
		
		return lSxNames;
	}
}








