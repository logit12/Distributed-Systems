import java.io.*;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.HashSet;
/**
 * @author lorraine
 *
 */

public class mapperDictionnary {


	// Methods

	public  HashMap<String, HashSet<String>> getMyDICO_WordToUM(HashMap<String, ArrayList<String>> param_UMxWordDico) throws IOException
	{
		System.out.println(param_UMxWordDico.toString());

		HashMap<String, HashSet<String>> myDICO_WordUMx = new HashMap<String, HashSet<String>>();

		for (int i = 0; i< param_UMxWordDico.size(); i++)
		{
			ArrayList<String> myUMxName = new ArrayList<String>();

			String UM_courant = (String) param_UMxWordDico.keySet().toArray()[i];
			myUMxName.add((String) param_UMxWordDico.keySet().toArray()[i]);



			ArrayList<String> keys_ = new ArrayList<String>();
			keys_ = (ArrayList<String>)param_UMxWordDico.get(UM_courant);

			//	System.out.println((String) myDICO_UM0.keySet().toArray()[i]);

			for(int j = 0; j< keys_.size(); j++)
			{
				String key = keys_.get(j);

				if(myDICO_WordUMx.containsKey(key) == false)
				{

					HashSet<String> list = new HashSet<String>();
					list.add(UM_courant);
					myDICO_WordUMx.put(key, list );

					//System.out.println(myDICO_UM.toString());

				}
				else
				{
					myDICO_WordUMx.get(key).add(UM_courant);
					//System.out.println(myDICO_UM.toString());
				}
			}

		}
		System.out.println(myDICO_WordUMx.toString());
		return myDICO_WordUMx;

	}

}
