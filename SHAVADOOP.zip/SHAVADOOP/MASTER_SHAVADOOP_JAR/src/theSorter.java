/**********************************************/
/*
 * This Class is in not yet finished
 * 
 */


import java.util.ArrayList;
import java.util.Collection;
import java.util.Collections;
import java.util.HashMap;
import java.util.LinkedHashMap;
import java.util.List;


public class theSorter {

	public  void quicksort(ArrayList<String> tableau, int start, int end) {
	    if (start < end) {
	        int indicePivot = partition(tableau, start, end);
	        quicksort(tableau, start, indicePivot-1);
	        quicksort(tableau, indicePivot+1, end);
	    }
	    
	    System.out.println(tableau.toString());
	}

	public  int partition (ArrayList<String> t, int start, int end) {
	    String valeurPivot = t.get(start);
	    int d = start+1;
	    int f = end;
	    while (d < f) {
	        while(d < f && t.get(f).compareTo(valeurPivot)>0) f--;
	        while(d < f && t.get(d).compareTo(valeurPivot)<0) d++;
	        String temp = t.get(d);
	        t.get(d).replace(t.get(d), t.get(f));
	        t.get(f).replace(t.get(f),  temp);
	    }
	    if (t.get(d).compareTo(valeurPivot)>0) d--;
	    t.get(start).replace( t.get(start), t.get(d));
	    t.get(d).replace(t.get(d), valeurPivot);
	    return d;
	}
	
	//public LinkedHashMap<Integer, String> sortHashMapByValues( HashMap<Integer, String> passedMap)
	public LinkedHashMap<String, ArrayList<String>> sortHashMapByValues( HashMap<String, ArrayList<String>> passedMap)
	{
	    List<String> mapKeys = new ArrayList<>(passedMap.keySet());
	    Collection<ArrayList<String>> mapValues = passedMap.values();
	    
	  //  Collections.sort(mapValues);
	    Collections.sort(mapKeys);

	    LinkedHashMap<String, ArrayList<String>>  sortedMap = new LinkedHashMap<>();
/*
	    Iterator<String> valueIt = mapValues.iterator();
	    
	    while (valueIt.hasNext()) {
	        String val = valueIt.next();
	        Iterator<Integer> keyIt = mapKeys.iterator();

	        while (keyIt.hasNext()) {
	            Integer key = keyIt.next();
	            String comp1 = passedMap.get(key);
	            String comp2 = val;

	            if (comp1.equals(comp2)) {
	                keyIt.remove();
	                sortedMap.put(key, val);
	                break;
	            }
	        }
	    }*/
	    return sortedMap;
	}
}
