import java.io.BufferedWriter;
import java.io.File;
import java.io.FileWriter;
import java.io.IOException;
import java.util.ArrayList;
import java.util.HashMap;

/**
 * @author lorraine
 *
 */
public class assembling {
	
	public  HashMap<String, Integer> doAssembling(String param_path, ArrayList<String> listStr) throws IOException
	{
		HashMap<String, Integer> dicoFinalMaster= new HashMap<String, Integer>();
		
		File newFile = new File( param_path + "SHAVADOOP_RESULTS.text");
		FileWriter fw2 = new FileWriter(newFile);
		BufferedWriter writer2 = new BufferedWriter(fw2);
		for (String str : listStr)
		{

		
			writer2.write(str  + "\r\n");
			String[] strSplitted = str.split(" ");
			

			dicoFinalMaster.put(strSplitted[0], Integer.parseInt(strSplitted[1]));
		}
		writer2.close();
		return dicoFinalMaster;
	}


}