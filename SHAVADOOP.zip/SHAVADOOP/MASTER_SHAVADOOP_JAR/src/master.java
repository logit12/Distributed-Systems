
import java.io.*;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.HashSet;
import java.util.Hashtable;
import java.util.Iterator;
import java.util.Set;
/**
 * @author lorraine
 *
 */

public class  master {

	// Attributs
	private static ArrayList<String> myGoodMachines;
	private static int nbSxFiles ;
	private static String PATH ;
	private static Hashtable<String, ArrayList<String>>  myDICO ;

	public static ArrayList<String> myUMxLines;

	public static HashMap<String, ArrayList<String>>  myDICO_UMxWordPath ;
	public static String workingMode;  //ModeSxUMx or ModeUMxSx
	private static String INPUT_FILE = /*"forestier_mayotte.text"; //*/"Input.text";
	private static String fileWithAllMachinesName ;
	private static String input_file_name;

	// Constructeur
	public  master() //ne sera pas appelÃ©
	{
		myDICO = new Hashtable<String, ArrayList<String>>();
		nbSxFiles = 0;
		myUMxLines = new ArrayList<String> ();
		myDICO_UMxWordPath = new HashMap<String, ArrayList<String>>();

	}


	public static void main(String[] args) throws Exception {

		/*Déclaration et initialisation de variables*/
		long startTime , endTime , totalTime ;

		HashMap<String, ArrayList<String>>  myDICO_UMxWord = new HashMap<String, ArrayList<String>>();
		HashMap<String, HashSet<String>>  myDICO_WordUMx = new HashMap<String, HashSet<String>>();
		HashMap<String, String>  myDICO_UMxMachines = new HashMap<String, String>();
		myDICO = new Hashtable<String, ArrayList<String>>();
		ArrayList<String> myRMxLines = new ArrayList<String>();

		String umxName = "";
		PATH = args[0]; // "/cal/homes/lnyembi/workspace/";
		fileWithAllMachinesName = args[1]; // "filetoread.text"; 
		input_file_name = args[2]; // /*"deontologie_police_nationale.txt"; //*/"Input.text";


		System.out.println("****************Collecte de machines viables pour le traitement*************************\n");

		startTime = System.currentTimeMillis();   
		machinesCollector machine = new machinesCollector();
		machine.getGoodMachines(PATH, fileWithAllMachinesName);
		myGoodMachines = machine.myGoodMachines;
		endTime  = System.currentTimeMillis();
		totalTime = endTime - startTime;
		int nbOfGoodMachines =  myGoodMachines.size();
		System.out.printf("\nTemps de Démarrage : %d ms\n\n",totalTime);

		System.out.println("\n*********Split Mapping en parallèle : découpage du fichier en sous-fichiers**************\n");


		/**************************************************************************************/
		/*
		/*								SPLITTING PROCESSING BY MASTER
		/*
		/**************************************************************************************/
		startTime = System.currentTimeMillis();

		fileCleaner cleaner = new fileCleaner();
		String cleaned_input_file_name = cleaner.applyCleanerToFile(PATH, input_file_name); 
		endTime  = System.currentTimeMillis();
		totalTime = endTime - startTime;
		System.out.printf("\nTemps de Cleaning : %d ms\n\n",totalTime);

		startTime = System.currentTimeMillis();
		fileSplitter splitter = new fileSplitter(nbOfGoodMachines, cleaned_input_file_name);
		nbSxFiles = splitter.splitLines(cleaned_input_file_name);
		endTime  = System.currentTimeMillis();
		totalTime = endTime - startTime;
		System.out.printf("\nTemps de Splitting : %d ms\n\n",totalTime);
		startTime = System.currentTimeMillis();


		System.out.printf("\n********Construction du dictionnaire “UMx - machines“*******************************\n\n");


		//nbSxFiles = splitter.mySxNames.size();
		System.out.printf("nbSxFiles %d\n", nbSxFiles);
		Runner_slave[] runner_slave_ModeSxUMx = new Runner_slave[nbOfGoodMachines];

		mapperDictionnary dico = new mapperDictionnary();


		workingMode= "ModeSxUMx";

		/**************************************************************************************/
		/*
		/*								MAPPING PROCESSING BY SLAVES
		/*
		/**************************************************************************************/


		if ((workingMode.compareTo("ModeSxUMx") )== 0)   
		{
			//System.out.printf("On lance SLAVE sur %s\n", myGoodMachines.get(i));

			for (int i = 0; i< nbSxFiles; i++)
			{

				String s= "UMx"+ (i+1);
				//System.out.printf("On lance SLAVE sur %s\n", myGoodMachines.get(i));
				System.out.printf("UMx%d - %s\n", i+1, myGoodMachines.get(i));

				myDICO_UMxMachines.put(s,  myGoodMachines.get(i));

			}
			System.out.println(myDICO_UMxMachines.toString());
			System.out.printf("\n********Fin Construction du dictionnaire “UMx - machines“*******************************\n");

			// Il ya autant de slave que de fichiers Sx et que de fichiers UMx
			for (int i = 0; i< nbSxFiles; i++)
			{

				runner_slave_ModeSxUMx[i] = new Runner_slave(myGoodMachines.get(i) , splitter.mySxNames.get(i), false); 
				//System.out.println(runner_slave[i].startDico);
				runner_slave_ModeSxUMx[i].start();

				/*runner_slave[i].join();
				String s= "UMx"+ (i+1);
				HashSet<String> myUMxName = new HashSet<String>();
				myUMxName.add(s);

				umxName = umxName + PATH + s + ".text ";

				for (int ii = 0; ii< runner_slave[i].myUMxLines.size(); ii++){
					myDICO_UMxWord.put(s,  runner_slave[i].myUMxLines);
				}*/

			}
			for (int i = 0; i< nbSxFiles; i++)
			{

				/*
				HashSet<String> myUMxName = new HashSet<String>();

				runner_slave[i] = new Runner_slave(myGoodMachines.get(i) , splitter.mySxNames.get(i), false); 

				System.out.println(runner_slave[i].startDico);
				runner_slave[i].start();*/
				runner_slave_ModeSxUMx[i].join();

				String s= "UMx"+ (i+1);
				HashSet<String> myUMxName = new HashSet<String>();
				myUMxName.add(s);

				umxName = umxName + PATH + s + ".text ";

				for (int ii = 0; ii< runner_slave_ModeSxUMx[i].myUMxLines.size(); ii++){
					myDICO_UMxWord.put(s,  runner_slave_ModeSxUMx[i].myUMxLines);
				}

			}
			myDICO_WordUMx = dico.getMyDICO_WordToUM(myDICO_UMxWord);
			workingMode= "ModeUMxSx";

		}

		endTime  = System.currentTimeMillis();
		totalTime = endTime - startTime;
		System.out.printf("\nTemps de Mapping : %d ms\n\n",totalTime);

		startTime = System.currentTimeMillis();
		Set<String> setOfKeys = myDICO_WordUMx.keySet();
		int setOfKeysSize = setOfKeys.size();
		Runner_slave[] runner_slave_ModeUMxSx = new Runner_slave[setOfKeysSize];
		
		if(workingMode.equals("ModeUMxSx") ==true)
		{

			Iterator<String> keyIt = setOfKeys.iterator();

			int i = 0;
			assembling finalMaster = new assembling();

			// Si il y a plus de machines que de clés, cette ligne ne pose pas de problèmes
			
		
			if(nbOfGoodMachines >= setOfKeysSize)
			{
				// Il y a autant de slaves de Keys
				while (keyIt.hasNext()) 
				{

					String valKey = keyIt.next();
					//System.out.println("valKey = " + valKey + "\n");

					runner_slave_ModeUMxSx[i] = new Runner_slave(myGoodMachines.get(i) , (i+1) , workingMode , valKey, splitter.mySxNames.get(0), umxName, false);
					runner_slave_ModeUMxSx[i].start();
					
					System.out.printf("Does thread %d still alive? answer: %s \n", i+1, runner_slave_ModeUMxSx[i].isAlive());

					// Si il y a moins de machines que de clés, chaque slave va s'occuper d'un lot de clés


				//	runner_slave[i].join();

				/*for (String lineRm : runner_slave[i].myRMxLines){
					myRMxLines.add(lineRm);
				}*/
					i++;
				}
				//i=0;
				System.out.printf("\n");

				for(i= 0; i< runner_slave_ModeUMxSx.length; i++) 
				{
			
					/* String valKey = keyIt.next();


					runner_slave[i] = new Runner_slave(myGoodMachines.get(i) , (i+1) , workingMode , valKey, splitter.mySxNames.get(0), umxName, false);

					runner_slave[i].start();*/
					// Si il y a plus de machines que de clés, cette ligne ne pose pas de problèmes

					runner_slave_ModeUMxSx[i].join();

					if(runner_slave_ModeUMxSx[i].myRMxLines.size() >0){
						for (String lineRm : runner_slave_ModeUMxSx[i].myRMxLines){
							
							myRMxLines.add(lineRm);
						}
					}
					
			
				}
			}
			// Si il y a plus de machines que de clés, cette ligne ne pose pas de problèmes
			// Envoyer au 4 paramètres le nombres de clé à traiter côté Slave
			else
			{
				int numberOfKeyToProccessBySlave = setOfKeysSize / nbOfGoodMachines;
				String packOfKeys = "";
				int cpt = 0;

				int j = 0;
				while (keyIt.hasNext()) 
				{

					String valKey = keyIt.next();
					System.out.println("valKey = " + valKey + "\n");

					if(setOfKeysSize % nbOfGoodMachines == 0) // repartition equitable entre les slaves
					{
						if(cpt< numberOfKeyToProccessBySlave && j < nbOfGoodMachines)
						{
							packOfKeys = packOfKeys + valKey + " ";
							runner_slave_ModeUMxSx[j] = new Runner_slave(myGoodMachines.get(j) , (j+1) , workingMode , packOfKeys, splitter.mySxNames.get(0), umxName, false);
							cpt ++;
						}
						else
						{
							cpt = 0;
							j ++;
							packOfKeys = "";
						}
					}
					else
					{
						if(j < nbOfGoodMachines-1)
						{
							if(cpt< numberOfKeyToProccessBySlave)
							{
								packOfKeys = packOfKeys + valKey + " ";
								runner_slave_ModeUMxSx[j] = new Runner_slave(myGoodMachines.get(j) , (j+1) , workingMode , packOfKeys, splitter.mySxNames.get(0), umxName, false);
								cpt ++;
							}
						}
						else if(j == nbOfGoodMachines-1)
						{
							packOfKeys = packOfKeys + valKey + " ";
							runner_slave_ModeUMxSx[j] = new Runner_slave(myGoodMachines.get(j) , (j+1) , workingMode , packOfKeys, splitter.mySxNames.get(0), umxName, false);
							cpt ++;
						}
						else
						{
							cpt = 0;
							j ++;
							packOfKeys = "";
						}
					}
				}
				
				for(i= 0; i< runner_slave_ModeUMxSx.length; i++) 
				{
					runner_slave_ModeUMxSx[i].join();
					for (String lineRm : runner_slave_ModeUMxSx[i].myRMxLines){
						
						myRMxLines.add(lineRm);
					}

				}

			}
			

			endTime  = System.currentTimeMillis();
			totalTime = endTime - startTime;
			System.out.printf("\nTemps de SHUFFLING/REDUCING : %d ms\n\n",totalTime);

			/**************************************************************************************/
			/*
			/*								ASSEMBLING PROCESSING BY MASTER
			/*
			/**************************************************************************************/
			startTime = System.currentTimeMillis();

			finalMaster.doAssembling(PATH, myRMxLines);

			endTime  = System.currentTimeMillis();
			totalTime = endTime - startTime;
			System.out.printf("\nTemps de ASSEMBLING : %d ms\n\n",totalTime);

		}

		System.out.println("****************Tout est fini***************************************************\n");

	}	

}