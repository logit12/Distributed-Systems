
import java.io.*;
import java.util.regex.*;

/**
 * @author lorraine
 *
 */

public class fileCleaner {


	public String applyCleanerToFile(String path, String dirtyFile) throws Exception  {

		//String input = "I have a cat, but I le vôtre 12 3 4 like my dog better le vôtre.";
		String mregex1 =
				"(je|tu|il|elle|nous|vous|ils|elles|le mien|le tien|le sien|vôtre|vôtres|le vôtre|le nôtre|le leur|"
						+ "la mienne|la tienne|la sienne|les miennes|es tiennes|"
						+ "les miens|les tiens|les siens|les vôtres|les leurs"
						+ "|l'|les|le|la|leur[leurs|eux|celui|celle)";
		/*+ "|celui-ci|celui-là|celle-ci|celle-là|ceci|cela|ça"
						+ "|les autres|l'autre|lui|on|d'aucune|l'un|l'une|d'un|d'une part|d'autre part|l'un et l'autre"
						+ "|l'une et l'autre|les uns et les autres|ni l'un ni l'autre"
						+ "|aucun(e)|d'aucun(e)|nul(e)|l'un(e)|l'un(e) et l'autre|ni l'un(e) ni l'autre"
						+ "|pas un(e)|pas un|pas une|tout le temps|quelqu'un(e)|quelqu'un|quelqu'une)";
		 */

		String mregex2 = "(↬|,|.|:|-)";
		//		String mregex2 = "(,|.|:|!|?|/|-|<|>|~|&|°|§|_|@|%|{|}|[|]|(|)|+|↬|=|*)";


		FileReader myFile;
		try {
			//System.out.println(path + dirtyFile);
			myFile = new FileReader(path + dirtyFile);
			File file = new File (path + "cleaned_" + dirtyFile );
			BufferedReader myBuff = new BufferedReader(myFile);
			BufferedWriter out = new BufferedWriter(new FileWriter(file));

			String line;
			while ((line = myBuff.readLine()) != null)
			{
				Pattern p2 = Pattern.compile("(je|tu|il|elle|nous|vous|ils|l'|s'|"
						+ "elles|le mien|le tien|le sien|vôtre|vôtres|le vôtre|le nôtre|le leur)");
				Matcher m = p2.matcher(line);

				if ( line.length() != 0){
					while (m.find()) {
						if(m.find() == true)
						{
							line = line.replaceAll(m.group(), "");
							//System.out.println("found a " + m.group() );
						}
					}
					line = line.replaceAll("([↬°.,!?])", "");
					out.write(line.replaceAll("(?!\'|-)\\p{Punct}|\\d", "")
							.replaceAll("^ +| +$|( )+", "$1").toLowerCase() + "\n");

				}
			}  
			out.close();

			myFile.close();
			myBuff.close();
		} catch (FileNotFoundException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		//mcleanedFile = PATH + "cleaned_" + mdirtyFile;
		return path + "cleaned_" + dirtyFile;
	}

}

