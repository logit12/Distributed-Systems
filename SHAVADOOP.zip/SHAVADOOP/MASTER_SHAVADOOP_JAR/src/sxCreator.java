import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.File;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;
import java.util.ArrayList;

/**
 * 
 */

/**
 * @author lorraine
 *
 */

public class sxCreator {


	public BufferedReader myBuff;
	int nbLinesPerMachine ;
	public  FileReader myFile;
	public ArrayList<String> mSxNames;
	public String line;
	public String PATH;

	public sxCreator(int param_totalNumberOfLines, BufferedReader paramBuff, FileReader paramFile)
	{
		myBuff= paramBuff;
		nbLinesPerMachine = param_totalNumberOfLines;
		myFile = paramFile;
		//PATH = "/home/lorraine/workspace/"; 
		PATH = "/cal/homes/lnyembi/workspace/";
		mSxNames = new ArrayList<String>();
		mSxNames.clear();
	}

	// In case of the number of lines is less than the number of available machine
	public int fillSx(BufferedReader paramBuff) throws IOException
	{

		int cptMachine = 1;
		ArrayList<String> sxNames = new ArrayList<String>();
		while ((line = paramBuff.readLine()) != null)
		{

			File newFile = new File( PATH + "Sx" + cptMachine + ".text");
			mSxNames.add(PATH + "Sx" + cptMachine + ".text");

			FileWriter fw2 = new FileWriter(newFile);
			BufferedWriter writer2 = new BufferedWriter(fw2);
			cptMachine = cptMachine + 1;
			writer2.write(line + "\r\n");
			writer2.close();

		}
		myFile.close();
		myBuff.close();
		return mSxNames.size();

	}
	// In case of the number of lines is higher than the number of available machine
	// And the rest of the division of both numbers is equal to 0
	public int fillSx_2(int param_nbLinesPerMachine, int param_nbOfMachines) throws IOException
	{
		int cptLine = 0;
		mSxNames.clear();
		for (int k = 0 ; k < param_nbOfMachines; k++)
		{
			File newFile = new File( PATH + "Sx" + (k+1) + ".text");
			FileWriter fw2 = new FileWriter(newFile);
			BufferedWriter writer2 = new BufferedWriter(fw2);
			mSxNames.add(PATH + "Sx" + (k+1) + ".text");
			while ((line = myBuff.readLine()) != null && cptLine < param_nbLinesPerMachine)
			{
				
				//System.out.println(PATH + "Sx" + k + ".text");
				writer2.write(line + "\r\n");
				cptLine += 1;
			}

			writer2.close();
			cptLine = 0;	
		}
		myFile.close();
		myBuff.close();
		return mSxNames.size();

	}
	// In case of the number of lines is higher than the number of available machine
	// And the rest of the division of both numbers is not equal to 0
	public int  fillSx_3(int param_nbLinesPerMachine, int param_nbOfMachines) throws IOException
	{
		int cptLine = 0;
		int kk = 0 ;
		mSxNames.clear();
		
		for (int k = 0 ; k < param_nbOfMachines; k++)
		{
			File newFile = new File( PATH + "Sx" + (k+1) + ".text");
			FileWriter fw2 = new FileWriter(newFile);
			BufferedWriter writer = new BufferedWriter(fw2);

			if(k<param_nbOfMachines-1)
			{
				System.out.printf("machine %d numb ligne par mach = %d\n", k+1, param_nbLinesPerMachine);
				mSxNames.add(PATH + "Sx" + (k+1) + ".text");
				while ((line = myBuff.readLine()) != null && cptLine < param_nbLinesPerMachine)
				{
					
					//System.out.println(PATH + "Sx" + k + ".text");
					writer.write(line + "\r\n");
					cptLine += 1;
				}		writer.close();
			}
	
			cptLine = 0;	
			kk = k+1;

		}
	

		File newFile = new File( PATH + "Sx" + param_nbOfMachines + ".text");
		FileWriter fw = new FileWriter(newFile);
		BufferedWriter writer2 = new BufferedWriter(fw);
		
		mSxNames.add(PATH + "Sx" + param_nbOfMachines + ".text");
		while ((line = myBuff.readLine()) != null /*&& cptLine < param_nbLinesPerMachine*/)
		{

			writer2.write(line + "\r\n");
			cptLine += 1;
		}

		writer2.close();

		myFile.close();
		myBuff.close();

		
		return mSxNames.size();
	}

}


