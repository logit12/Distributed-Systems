
import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.File;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.Hashtable;
import java.util.Enumeration;

public class slave {





	public static void main(String[]  args) throws InterruptedException, IOException {


		
		/**************************************************************************************/
		/*
		/*								MAPPING PROCESSING BY SLAVES
		/*
		/**************************************************************************************/
		
		if(args.length < 2)
		// On initialise les UMx
		{
			
			
			wordMapper mapping = new wordMapper(args[0]);
			mapping.doMapping();
			
			
			/*"***********************Stockage des clés pour envoie au Master****************"*/

		
			mapping.getKeyOfDicoPerSxFile();

		}
		else
		// On initialise les SMx, RMx
		{
			
			/**************************************************************************************/
			/*
			/*								SHUFFLING PROCESSING BY SLAVES
			/*
			/**************************************************************************************/
			
			wordMapper mapping = new wordMapper();
	
			int sizeArgs = args.length;
			
			String[] param_allUMxPathToLookIn = new String[sizeArgs - 4];
			for (int k =4; k<sizeArgs; k++)
			{
				 param_allUMxPathToLookIn[k-4] = args[k];
				
			}
				
			HashMap<String, ArrayList<Integer>> dicoShufflingPerUMxFile= new HashMap<String, ArrayList<Integer>>();
			dicoShufflingPerUMxFile = mapping.doShuffling(args[2], param_allUMxPathToLookIn, Integer.parseInt(args[1]));
			
			
			/**************************************************************************************/
			/*
			/*								REDUCING PROCESSING BY SLAVES
			/*
			/**************************************************************************************/

		
			mapping.doReducing(dicoShufflingPerUMxFile, Integer.parseInt(args[1]));
			
			
		}




	}

}
