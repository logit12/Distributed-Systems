import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.File;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.Hashtable;
import java.util.Enumeration;
import java.util.Iterator;

public class wordMapper {

	private String PATH;
	private  Hashtable<String, Integer>  myDICO ;
	String slaveInputFile;

	public wordMapper(String paramSlaveFile)
	{
		PATH = "/cal/homes/lnyembi/workspace/";
		myDICO = new Hashtable<String, Integer>();
		slaveInputFile = paramSlaveFile;
	}

	public wordMapper()
	{
		PATH = "/cal/homes/lnyembi/workspace/";
	}

	public  String getNumMachineFromSxPath()
	{

		String val = slaveInputFile.split("Sx")[1]; 

		/*paramSlaveFile.charAt(paramSlaveFile.indexOf(".")-1)*/
		return val;
	}


	public  void doMapping() throws IOException
	{

		//createDicoPerSxFile
		BufferedReader buff;
		FileReader file;
		String cptMachine = getNumMachineFromSxPath( );


		File newFile = new File( PATH + "UMx" + cptMachine);

		//System.out.println(cptMachine);
		FileWriter fw2 = new FileWriter(newFile);
		BufferedWriter writer2 = new BufferedWriter(fw2);


		try {
			String line;
			if (! slaveInputFile.isEmpty())
			{
				file = new FileReader(slaveInputFile);
				buff = new BufferedReader(file);

				/*Q26*/
				while ((line = buff.readLine()) != null)
				{					

					String[] allWordsInFile  = line.split(" ");

					int  sizeFile = allWordsInFile.length;



					// Création d'un nouveau Hashtable
					Hashtable<String, Integer> hMyDicoPerSxFile= new Hashtable<String, Integer>();
					String word = "";

					for (int j = 0; j<sizeFile; j++)  //  line.split(" ") renvoie un tableau de mots
					{
						word = allWordsInFile[j];
						// remplissage du Hashtable
						hMyDicoPerSxFile.put(word, 1);

						// Ecrire dans le fichier le dictionnaire
						//Enumeration<String> keys = hMyDicoPerSxFile.keys();

						/*String key = (String)keys.nextElement();
						System.out.println( hMyDicoPerSxFile.toString());
						int stateName = (int)hMyDicoPerSxFile.get(key);

						System.out.println( key + " : " + stateName );*/

						//System.out.println( word + " : " + 1 );

						writer2.write(word + " " + 1  + "\r\n");


						/*while (keys.hasMoreElements())
						{
							//System.out.println( "toto" );
							key = (String)keys.nextElement();
							stateName = (int)hMyDicoPerSxFile.get(key);
							System.out.println( key + " : " + stateName );

							writer2.write(key + " " + stateName  + "\r\n");
						} // end while*/


					}
					myDICO = hMyDicoPerSxFile;

				}
			}
			writer2.close();
		} catch (IOException e) {
			e.printStackTrace();
		}



	}

	public  void getKeyOfDicoPerSxFile() throws IOException
	{
		// Affiche les clés du dictionnaire
		Enumeration<String> keys = myDICO.keys();
		//System.out.printf("\nUMx%s, keys are:\r\n", slaveInputFile.split("Sx")[1]);


		while (keys.hasMoreElements())
		{
			String key = (String)keys.nextElement();
			System.out.println( key);
		}


	}

	public  void createOutputStreamDicoPerUMxFile() throws IOException
	{
		// Affiche les UMx et leurs clés
		Enumeration<String> keys = myDICO.keys();

		StringBuffer buffer = new StringBuffer();

		buffer.append("UMx" + slaveInputFile.split("Sx")[1].substring(0, 1) + "\r\n" );


		while (keys.hasMoreElements())
		{
			String key = (String)keys.nextElement();
			buffer.append(key + "\r\n");
		}

		int sizeBuffer = buffer.length();
		buffer = buffer.delete(sizeBuffer-1, sizeBuffer);

		//buffer.append(">");

		System.out.println( buffer.toString());
	}

	public HashMap<String, ArrayList<Integer>> doShuffling(String param_keyToSearch , String[] param_allUMxPathToLookIn, int param_idRMx) throws IOException
	{

		BufferedReader buff;
		FileReader file;

		HashMap<String, ArrayList<Integer>> dicoSMxPerUMxFile= new HashMap<String, ArrayList<Integer>>();
		ArrayList<Integer> cptKey = new ArrayList<Integer>();
		File newFile = new File( PATH + "SMx" + param_idRMx);


		FileWriter fw2 = new FileWriter(newFile);
		BufferedWriter writer2 = new BufferedWriter(fw2);


		try {
			String line;
			for (String umxPath : param_allUMxPathToLookIn) {
				{

					file = new FileReader(umxPath);
					buff = new BufferedReader(file);
					while ((line = buff.readLine()) != null)
					{					
						String firstWordInLine  = line.split(" ")[0];  // je prends le premier mot

						if (param_keyToSearch.compareTo(firstWordInLine) ==0)
						{	
							writer2.write(param_keyToSearch + " " + 1  + "\r\n");
							cptKey.add(1);
							dicoSMxPerUMxFile.put(param_keyToSearch, cptKey);

						}

					}
				}

				buff.close();   //not sure
			}
			writer2.close();
		}catch (IOException e) {
			e.printStackTrace();
		}

		//System.out.println(dicoSMxPerUMxFile.toString());
		return dicoSMxPerUMxFile;

	}


	public void doReducing(HashMap<String, ArrayList<Integer>> dicoShufflingPerUMxFile,  int param_idRMx) throws IOException
	{

		HashMap<String, Integer> dicoRMxPerSMxFile= new HashMap<String, Integer>();
		ArrayList<Integer> cptKey = new ArrayList<Integer>();

		File newFile = new File( PATH + "RMx" + param_idRMx);
		FileWriter fw2 = new FileWriter(newFile);
		BufferedWriter writer2 = new BufferedWriter(fw2);

		Iterator<String> iterKey = dicoShufflingPerUMxFile.keySet().iterator();
		while(iterKey.hasNext())
		{
			String currentKey = iterKey.next();
			cptKey = dicoShufflingPerUMxFile.get(currentKey);
			writer2.write(currentKey + " " +  Integer.toString(cptKey.size())  + "\r\n");
			dicoRMxPerSMxFile.put(currentKey, cptKey.size());

		}
		writer2.close();
		
	}


}
