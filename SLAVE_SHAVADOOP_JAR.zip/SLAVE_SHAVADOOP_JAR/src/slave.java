
import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.File;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.Hashtable;
import java.util.Enumeration;

public class slave {




	/*	public static String getNumMachineFromSxPath(String paramSlaveFile)
	{

		String val = paramSlaveFile.split("Sx")[1]; 

		paramSlaveFile.charAt(paramSlaveFile.indexOf(".")-1)
		return val;
	}
	 */
	/*public static void createDicoPerSxFile(String paramSlaveFile) throws IOException
	{

		BufferedReader buff;
		FileReader file;
		String cptMachine = getNumMachineFromSxPath( paramSlaveFile);


		File newFile = new File("/cal/homes/lnyembi/workspace/UMx" + cptMachine);

		//System.out.println(cptMachine);
		FileWriter fw2 = new FileWriter(newFile);
		BufferedWriter writer2 = new BufferedWriter(fw2);


		try {
			String line;
			if (! paramSlaveFile.isEmpty())
			{
				file = new FileReader(paramSlaveFile);
				buff = new BufferedReader(file);

				Q26
				while ((line = buff.readLine()) != null)
				{					

					String[] allWordsInFile  = line.split(" ");

					int  sizeFile = allWordsInFile.length;


					// Création d'un nouveau Hashtable
					Hashtable<String, Integer> hMyDicoPerSxFile= new Hashtable<String, Integer>();
					String word = "";

					for (int j = 0; j<sizeFile; j++)  //  line.split(" ") renvoie un tableau de mots
					{
						word = allWordsInFile[j];


						// remplissage du Hashtable
						hMyDicoPerSxFile.put(word, 1);

						// Ecrire dans le fichier le dictionnaire
						Enumeration<String> keys = hMyDicoPerSxFile.keys();
						String key = (String)keys.nextElement();
						int stateName = (int)hMyDicoPerSxFile.get(key);

						System.out.println( key + " : " + stateName );
						writer2.write(key + " " + stateName  + "\r\n");
						// prints "New York"

						while (keys.hasMoreElements())
						{
							//System.out.println( "toto" );
							key = (String)keys.nextElement();
							stateName = (int)hMyDicoPerSxFile.get(key);
							System.out.println( key + " : " + stateName );

							writer2.write(key + " " + stateName  + "\r\n");
						} // end while


					}
					myDICO = hMyDicoPerSxFile;

				}
			}
			writer2.close();
		} catch (IOException e) {
			e.printStackTrace();
		}


	}
	 */
	/*	public static void getKeyOfDicoPerSxFile(String paramSlaveFile) throws IOException
	{
		// Affiche les clés du dictionnaire
		Enumeration<String> keys = myDICO.keys();
		System.out.printf("\nFor Sx%s, keys are:\r\n", paramSlaveFile.split("Sx")[1]);
		while (keys.hasMoreElements())
		{
			String key = (String)keys.nextElement();
			System.out.println( key);
		}


	}*/

	public static void main(String[]  args) throws InterruptedException, IOException {


		//Question 19 du TP

		/*System.out.println(":avant calcul");
		Thread.sleep(10000);
		System.out.println( ":apres calcul");*/

		//	if()

		/**************************************************************************************/
		/*
		/*								MAPPING PROCESSING BY SLAVES
		/*
		/**************************************************************************************/
		
		if(args.length < 2)
		// On initialise les UMx
		{
			
			
			wordMapper mapping = new wordMapper(args[0]);
			mapping.doMapping();
			
			
			/*"***********************Stockage des clés pour envoie au Master****************"*/

		
			mapping.getKeyOfDicoPerSxFile();



		}
		else
		// On initialise les SMx, RMx
		{
			
			/**************************************************************************************/
			/*
			/*								SHUFFLING PROCESSING BY SLAVES
			/*
			/**************************************************************************************/
			
			wordMapper mapping = new wordMapper();
	
			int sizeArgs = args.length;
			
			String[] param_allUMxPathToLookIn = new String[sizeArgs - 4];
			for (int k =4; k<sizeArgs; k++)
			{
				 param_allUMxPathToLookIn[k-4] = args[k];
				
			}
				
			HashMap<String, ArrayList<Integer>> dicoShufflingPerUMxFile= new HashMap<String, ArrayList<Integer>>();
			dicoShufflingPerUMxFile = mapping.doShuffling(args[2], param_allUMxPathToLookIn, Integer.parseInt(args[1]));
			
			
			/**************************************************************************************/
			/*
			/*								REDUCING PROCESSING BY SLAVES
			/*
			/**************************************************************************************/

		
			mapping.doReducing(dicoShufflingPerUMxFile, Integer.parseInt(args[1]));
			
			
		}




	}

}
